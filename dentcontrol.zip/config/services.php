<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    'copomex' => [
        'token' => env('COPOMEX_TOKEN'),
        'base_url' => env('COPOMEX_BASE_URL', 'https://api.copomex.com'),
        'timeout' => env('COPOMEX_TIMEOUT', 8),
    ],

    'sepomex' => [
        'file_path' => env('SEPOMEX_FILE_PATH'),
        'delimiter' => env('SEPOMEX_FILE_DELIMITER'),
    ],

    // Agrega esto:
    'firebase' => [
    'credentials' => env('FIREBASE_CREDENTIALS', storage_path('app/firebase-credentials.json')),
    'project_id'  => env('FIREBASE_PROJECT_ID'),
    ],
];
